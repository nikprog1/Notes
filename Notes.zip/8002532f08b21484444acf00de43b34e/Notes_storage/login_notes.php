<?php
	session_start(); 
	$title= "Логин и регистрация"; 
	require_once "header.php";
	StartDB();
	CheckLogin();
?>

